Hello! You've arrived to my README. Welcome.

This project was made using Python 3.10.4

To run this program, enter the directory from your terminal for "lab1". Then execute the following function: 
python3 main.py input.txt output.txt
You can change the output.txt name to anything you would like. The input file could be named anything as well, just make sure a .txt file of that name exists in the same directory. After you run the program, a new file by the name of whatever you wrote as the second command argument will appear in the directory. If you run the program twice with the same output file name, it will overwrite it, so be careful!

Happy coding!